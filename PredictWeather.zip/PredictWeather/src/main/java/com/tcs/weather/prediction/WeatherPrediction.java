package com.tcs.weather.prediction;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.text.StrSubstitutor;
import org.apache.mahout.classifier.sgd.L1;
import org.apache.mahout.classifier.sgd.OnlineLogisticRegression;
import org.apache.mahout.math.Vector;

import com.tcs.weather.prediction.constants.ApplicationConstant;
import com.tcs.weather.prediction.vo.WeatherData;
import com.tcs.weather.prediction.vo.WeatherPredictionVO;

/**
 * The Class WeatherPrediction.
 * 
 * For weather prediction
 */
public class WeatherPrediction {

	/**
	 * main method
	 *
	 * @param
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		WeatherPrediction weatherPredictionObj = new WeatherPrediction();

		// method to load the parse the training data
		List<WeatherData> trainingData = weatherPredictionObj
				.parseTrainingData(ApplicationConstant.TRAINING_DATA_FILE_PATH);

		// Method to create the training model
		OnlineLogisticRegression onlineLogisticRegression = weatherPredictionObj.createTrainingModel(trainingData);

		// method call to predict weather
		predictWeather(onlineLogisticRegression, ApplicationConstant.INPUT_FILE_PATH);

	}

	/**
	 * To Predict weather based on various climatic conditions.
	 * 
	 * @throws IOException
	 *
	 */
	public static void predictWeather(OnlineLogisticRegression onlineLogisticRegression, String inputFilePath)
			throws IOException {
		BufferedReader in = null;
		String inputLine;
		try {
			in = new BufferedReader(new FileReader(inputFilePath));
			while ((inputLine = in.readLine()) != null) {
				String weatherCat = null;
				String[] values = inputLine.split(ApplicationConstant.WEATHER_DELIMITER, -1);
				if (!values[0].trim().equalsIgnoreCase(ApplicationConstant.LOCATION)) {
					String[] reqValues = { values[4], values[5], values[6], values[7], "4" };
					WeatherData newObservation = new WeatherData(reqValues);
					Vector result = onlineLogisticRegression.classifyFull(newObservation.getVector());
					//fetching the input values
					String location = values[0].replace("\"", "").trim();
					String latiduteStr = values[2].replace("\"", "").trim();
					String elevationStr = values[1].replace("\"", "").trim();
					double elevation = Double.parseDouble(elevationStr);
					double latitude = Double.parseDouble(latiduteStr);
					String longitudeStr = values[3].replace("\"", "").trim();
					double longitude = Double.parseDouble(longitudeStr);
					String forecastDate=values[4].replace("\"", "").trim();
					String pressureStr = values[5].replace("\"", "").trim();
					double pressure = Double.parseDouble(pressureStr);
					String tempMaxStr = values[6].replace("\"", "").trim();
					double tempMax = Double.parseDouble(tempMaxStr);
					String rhMaxStr = values[7].replace("\"", "").trim();
					double rhMax = Double.parseDouble(rhMaxStr);
					
					//checking out the weather category
					if ((Double) result.get(0) > ApplicationConstant.ACCURACY_RANGE) {
						weatherCat = ApplicationConstant.RAINY;
					} else if ((Double) result.get(1) > ApplicationConstant.ACCURACY_RANGE) {
						weatherCat = ApplicationConstant.SNOW;
					} else if ((Double) result.get(2) > ApplicationConstant.ACCURACY_RANGE) {
						weatherCat = ApplicationConstant.SUNNY;
					}

					// setting the values into the VO
					WeatherPredictionVO weatherPredictionVO = new WeatherPredictionVO();
					weatherPredictionVO.setLocation(location);
					weatherPredictionVO.setLatitude(latitude);
					weatherPredictionVO.setLongitude(longitude);
					weatherPredictionVO.setElevation(elevation);
					weatherPredictionVO.setForecastDate(forecastDate);
					weatherPredictionVO.setMaxTemp(tempMax);
					weatherPredictionVO.setPressure(pressure);
					weatherPredictionVO.setMaxRh(rhMax);
					weatherPredictionVO.setWeatherCondition(weatherCat);
					WeatherPrediction weatherPredictionObj=new WeatherPrediction();
					// method call to check out the weather condition
					String output = weatherPredictionObj.constructOuput(weatherPredictionVO);
					// printing the output
					System.out.println(output);
				}
			}
		} catch (IOException ioException) {
			
		} finally {
			in.close();
		}
	}

	/**
	 * Constructing the output string.
	 *
	 * @param WeatherPredictionVO
	 *            the weather prediction vo
	 * @param String
	 *            the weather
	 */
	public String constructOuput(WeatherPredictionVO weatherPredictionVO) {
		// constructing the template for loading the output
		String outputTemplate = ApplicationConstant.OUTPUT_TEMPLATE;
		// setting the data in the map
		Map<String, String> data = new HashMap<String, String>();
		data.put("location", weatherPredictionVO.getLocation());
		data.put("latitude", String.valueOf(weatherPredictionVO.getLatitude()));
		data.put("longitude", String.valueOf(weatherPredictionVO.getLongitude()));
		data.put("elevation", String.valueOf(weatherPredictionVO.getElevation()));
		data.put("timestamp", weatherPredictionVO.getForecastDate());
		data.put("weather", weatherPredictionVO.getWeatherCondition());
		data.put("temperature", String.valueOf(weatherPredictionVO.getMaxTemp()));
		data.put("pressure", String.valueOf(weatherPredictionVO.getPressure()));
		data.put("humidity", String.valueOf(weatherPredictionVO.getMaxRh()));
		// formatting the output with the template
		String formattedOutput = StrSubstitutor.replace(outputTemplate, data);
		return formattedOutput;
	}

	/**
	 * @param inputFilePath
	 * @return
	 */
	public List<WeatherData> parseTrainingData(String inputFilePath) {
		List<WeatherData> result = new ArrayList<>();
		String line = "";
		try (BufferedReader br = new BufferedReader(new FileReader(new File(inputFilePath)));) {
			// Skip the first line which contains the header values
			line = br.readLine();
			// Prepare the observation data
			while ((line = br.readLine()) != null) {
				String[] values = line.split(ApplicationConstant.WEATHER_DELIMITER, -1);
				result.add(new WeatherData(values));
			}
		} catch (IOException ioException) {

		}
		return result;
	}

	/**
	 * @param trainingData
	 * @return
	 */
	public OnlineLogisticRegression createTrainingModel(List<WeatherData> trainingData) {
		OnlineLogisticRegression onlineLogisticRegression = new OnlineLogisticRegression(
				ApplicationConstant.CATEGORIES, ApplicationConstant.WEATHER_FEATURES, new L1());
		// Train the model using 30 passes
		for (int pass = 0; pass < 30; pass++) {
			for (WeatherData weatherData : trainingData) {
				onlineLogisticRegression.train(weatherData.getActual(), weatherData.getVector());
			}
		}
		return onlineLogisticRegression;
	}

}
