package com.tcs.weather.prediction.constants;

/**
 * The Class ApplicationConstant.
 * 
 * Application constants
 */ 
public class ApplicationConstant {

	public static final int NO_CELLS=14;
	public static final String INPUT_FILE_PATH = "data/input-data.csv";
	public static final String TRAINING_DATA_FILE_PATH = "data/train-data.csv";
	//public static final String FILE_PATH = "C:/Users/252151/Downloads/blocks_forecast.csv";
	public static final String RAINY="Rain";
	public static final String SUNNY="Sunny";
	public static final String SNOW="Snow";
	public static final double ACCURACY_RANGE=0.75;
	public static final String LOCATION="Location";
	public static final String PIPE_SEPERATOR="| ";
	public static final String COMMA_SEPERATOR=", ";
	public static final String OUTPUT_TEMPLATE="${location}|${latitude},${longitude},${elevation}|${timestamp}|${weather}|${temperature}|${pressure}|${humidity}";
	
	public static final int WEATHER_FEATURES = 5;
	public static final String WEATHER_DELIMITER = "\\,";
	public static final int CATEGORIES = 3;
}
