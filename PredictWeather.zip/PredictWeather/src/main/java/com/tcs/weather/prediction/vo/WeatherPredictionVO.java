package com.tcs.weather.prediction.vo;

/**
 * The Class WeatherPredictionVO.
 * 
 * VO of weather prediction
 */ 
public class WeatherPredictionVO {

	private String location;
	private double latitude;
	private double longitude;
	private double elevation;
	private String forecastDate;
	private double maxTemp;
	private double pressure;
	private double maxRh;
	private String weatherCondition;
	
	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}
	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	/**
	 * @return the lattitude
	 */
	public double getLatitude() {
		return latitude;
	}
	/**
	 * @param lattitude the lattitude to set
	 */
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	/**
	 * @return the longitude
	 */
	public double getLongitude() {
		return longitude;
	}
	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	/**
	 * @return the elevation
	 */
	public double getElevation() {
		return elevation;
	}
	/**
	 * @param elevation the elevation to set
	 */
	public void setElevation(double elevation) {
		this.elevation = elevation;
	}
	/**
	 * @return the forecastDate
	 */
	public String getForecastDate() {
		return forecastDate;
	}
	/**
	 * @param forecastDate the forecastDate to set
	 */
	public void setForecastDate(String forecastDate) {
		this.forecastDate = forecastDate;
	}
	/**
	 * @return the maxTemp
	 */
	public double getMaxTemp() {
		return maxTemp;
	}
	/**
	 * @param maxTemp the maxTemp to set
	 */
	public void setMaxTemp(double maxTemp) {
		this.maxTemp = maxTemp;
	}
	/**
	 * @return the pressure
	 */
	public double getPressure() {
		return pressure;
	}
	/**
	 * @param pressure the pressure to set
	 */
	public void setPressure(double pressure) {
		this.pressure = pressure;
	}
	/**
	 * @return the maxRh
	 */
	public double getMaxRh() {
		return maxRh;
	}
	/**
	 * @param maxRh the maxRh to set
	 */
	public void setMaxRh(double maxRh) {
		this.maxRh = maxRh;
	}
	/**
	 * @return the weatherCondition
	 */
	public String getWeatherCondition() {
		return weatherCondition;
	}
	/**
	 * @param weatherCondition the weatherCondition to set
	 */
	public void setWeatherCondition(String weatherCondition) {
		this.weatherCondition = weatherCondition;
	}
	
	
	
	
}
