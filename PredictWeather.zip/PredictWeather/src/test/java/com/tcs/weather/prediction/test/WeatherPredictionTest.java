package com.tcs.weather.prediction.test;

import java.io.IOException;
import java.util.List;

import org.apache.mahout.classifier.sgd.OnlineLogisticRegression;
import org.junit.Test;

import com.tcs.weather.prediction.WeatherPrediction;
import com.tcs.weather.prediction.constants.ApplicationConstant;
import com.tcs.weather.prediction.vo.WeatherData;

/**
 * The Class WeatherPrediction.
 * 
 * For weather prediction
 */

@SuppressWarnings("deprecation")
public class WeatherPredictionTest {
	
	/**
	 *  To test Predict weather based on various climatic conditions.
	 * @throws IOException 
	 *
	 */
	@Test
	public void testPredictWeather(){
		
		try {
			//Junit test case to run the weather prediction method
			WeatherPrediction weatherPredictionObj=new WeatherPrediction();
			// method to load the parse the training data
			List<WeatherData> trainingData = weatherPredictionObj.parseTrainingData(ApplicationConstant.TRAINING_DATA_FILE_PATH);

			// Method to create the training model
			OnlineLogisticRegression onlineLogisticRegression = weatherPredictionObj.createTrainingModel(trainingData);

			weatherPredictionObj.predictWeather(onlineLogisticRegression, ApplicationConstant.INPUT_FILE_PATH);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
